#include <iostream>
#include <fstream>
#include <conio.h>
#include <cstdio>
using namespace std;

class User
{
private:
    string username;
    int userPassword, userID;

public:
    void setUserInfo(string newUsername, int newPassword, int newID)
    {
        username = newUsername;
        userPassword = newPassword;
        userID = newID;
    }

    string getUsername()
    {
        return username;
    }

    int getUserPassword()
    {
        return userPassword;
    }

    int getUserID()
    {
        return userID;
    }
};

class SignUpSystem
{
public:
    User *userList[2];
    int enteredID;
    int enteredPassword;
    int userCount = 0;
    string username;
    int userPassword, accountNumber, userID;

    int getSignUpInfo()
    {
        userList[userCount] = new User;
        cout << "Enter ID Number: ";
        cin >> userID;
        cout << "Enter name: ";
        cin >> username;
        cout << "Enter password: ";
        cin >> userPassword;
        userList[userCount]->setUserInfo(username, userPassword, userID);
        userCount++;
        return userID;
    }

    int getLoginInfo()
    {
        string successMessage = "Login Successful, Welcome :)";
        int loginAttempts = 0;

        cout << "Enter your ID Number: ";
        cin >> enteredID;
        cout << "Enter your Password: ";
        cin >> enteredPassword;

        ifstream loginFile("save2.txt");

        while (loginFile >> userID >> username >> userPassword)
        {
            if (userID == enteredID && userPassword == enteredPassword)
            {
                system("cls");



                cout << "Information of Account" << endl;
                cout << "Name: " << username << endl;
                cout << "ID: " << userID << endl;
                loginFile.close();
                loginAttempts++;
                break;
            }
        }

        if (loginAttempts == 0)
        {
            system("cls");

            cout << "Wrong ID or Password. Try Again!" << endl;
            getLoginInfo();
        }
        return userID;
    }

    void saveUserInfo()
    {
        ofstream saveFile("save2.txt", ios::app);
        if (saveFile.is_open())
        {
            for (int i = 0; i < userCount; i++)
            {
                saveFile << userList[i]->getUserID() << " ";
                saveFile << userList[i]->getUsername() << " ";
                saveFile << userList[i]->getUserPassword() << " ";
            }
            saveFile << endl;
        }
        saveFile.close();
    }

    void promptUser()
    {
        int userOption;

        while (true)
        {


            cout << "Enter 1 to Sign up" << endl;
            cout << "Enter 2 to Log in" << endl;
            cin >> userOption;
            system("cls");

            switch (userOption)
            {
                case 1:
                    getSignUpInfo();
                    saveUserInfo();
                    system("cls");

                    cout << "Registered" << endl;
                    break;

                case 2:
                    getLoginInfo();
                    break;

                default:
                    cout << "Invalid option. Please try again." << endl;
                    break;
            }
        }
    }
};

int main()
{
    SignUpSystem signUpSystem;
    signUpSystem.promptUser();
    return 0;
}
